﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    void random_array(int[] a, int n)
    {
        Random r = new Random();
        for (int i = 0; i < 2 * n * n; i++)
        {
            int op = 2 * n;
            a[i] = r.Next(op * op -1) + 1;
            for (int j = 0; j < i; j++)
                if (a[i] == a[j] || a[i] % 2 == 0)
                {
                    --i;
                    break;
                }
        }
    }

    void odd_random_array(int[] a, int n)
    {
        random_array(a, n);
        for (int i = 0; i < n; i++) a[i] = a[i] * 2 - 1;
    }


    void print(int[] a,int[] b, int n)
    {
        for (int i = 0; i < n; i++)
        {
            for (int l = 0; l < 2 * n; l ++)
            {
                if(b[i*n + l] == 0) Label1.Text += "*  ";
                else Label1.Text += a[i * n + l] + "  ";
            }
            Label1.Text += "<br/>";
        }
        
    }

    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void GO_Click(object sender, EventArgs e)
    {
        int N = Convert.ToInt32(n.Text);
        int[] a = new int[2 * N * N];
        int[] b = new int[2 * N * N];
        random_array(a, N);
        print(a, b, N);
        /*for (int i = 0; i < 2 * N * N; i++ )
        {
            Label1.Text += "<br/>" + a[i];
        }*/

    }
    protected void RUN_Click(object sender, EventArgs e)
    {

    }
}